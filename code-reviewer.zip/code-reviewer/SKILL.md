---
name: code-reviewer
description: This skill should be used when performing code reviews, reviewing pull requests, or providing feedback on code changes. It provides structured review criteria, common issue patterns to check, and feedback guidelines to ensure thorough and constructive code reviews.
---

# Code Reviewer

## Overview

This skill provides a structured approach to reviewing code changes. It defines clear review criteria, identifies common code issues, and guides the reviewer to provide constructive, actionable feedback. Use this skill when asked to review code, evaluate PRs, or assess code quality.

## When to Use This Skill

Trigger this skill when:
- User asks to review code, PR, or pull request
- User wants feedback on code changes
- User requests code quality assessment
- User asks to check for bugs, security issues, or code smells
- User wants a second opinion on implementation

## Review Workflow

### Step 1: Understand the Context

Before diving into the review:
1. Identify what files changed and their purposes
2. Understand the feature or fix being implemented
3. Note any related issues, specs, or requirements
4. Check if there are test files accompanying the changes

### Step 2: Review Categories

Evaluate code across these dimensions:

#### Correctness
- Does the code do what it's supposed to do?
- Are edge cases handled properly?
- Are there potential bugs or race conditions?
- Does it handle errors gracefully?

#### Security
- Is user input properly validated and sanitized?
- Are there potential injection vulnerabilities?
- Are credentials or secrets handled securely?
- Are file paths and resources properly validated?

#### Performance
- Are there unnecessary computations or loops?
- Is caching used where appropriate?
- Are large data structures handled efficiently?
- Are there potential memory leaks?

#### Maintainability
- Is the code readable and well-organized?
- Are function/variable names descriptive?
- Is there appropriate documentation?
- Are functions single-purpose and focused?

#### Style & Standards
- Does code follow language conventions?
- Are there consistent naming patterns?
- Is formatting consistent?
- Are there commented-out debug statements?

### Step 3: Common Issue Patterns

Watch for these frequent problems:

| Category | Pattern | What to Look For |
|----------|---------|------------------|
| Correctness | Off-by-one errors | Loop boundaries, array indices |
| Correctness | Null handling | Missing null checks, unhandled None |
| Security | SQL injection | String concatenation in queries |
| Security | XSS | Unescaped user input in output |
| Performance | N+1 queries | Loops that execute queries |
| Performance | Unnecessary copying | Creating copies in hot paths |
| Style | Magic numbers | Unnamed constant values |
| Style | Long functions | Functions doing multiple things |
| Style | Deep nesting | Excessive indentation levels |

### Step 4: Provide Feedback

Structure feedback clearly:

1. **Summary**: Brief overview of the review
2. **Strengths**: What was done well
3. **Issues Found**: Specific problems with severity
   - 🔴 Critical: Must fix before merge
   - 🟡 Warning: Should address, but not blocking
   - 🟢 Suggestion: Optional improvements
4. **Approve/Request Changes**: Clear recommendation

### Step 5: Severity Guidelines

**Critical (🔴)**
- Security vulnerabilities
- Data corruption risks
- Crashes or hangs
- Broken functionality

**Warning (🟡)**
- Performance issues
- Maintainability concerns
- Missing error handling
- Incomplete edge case handling

**Suggestion (🟢)**
- Code style improvements
- Documentation additions
- Alternative approaches
- Refactoring opportunities

## Review Checklist

Before completing a review, verify:

- [ ] All changed files are intentional
- [ ] Tests exist and pass
- [ ] No hardcoded secrets or credentials
- [ ] Error handling is present
- [ ] Documentation is updated if needed
- [ ] No debug code left behind
- [ ] Dependencies are properly managed

## Output Format

Provide reviews in this format:

```
## Code Review Summary

### Files Reviewed
- file1.ext
- file2.ext

### Overview
[Brief description of what was reviewed]

### ✅ Strengths
- [What was done well]

### ⚠️ Issues Found

#### 🔴 Critical
1. **[Issue]**: [Description]
   - Location: [file:line or function]
   - Suggestion: [How to fix]

#### 🟡 Warnings
...

#### 🟢 Suggestions
...

### Recommendation
[Approve / Request Changes]

### Notes
[Any additional context]
```

## Examples

### Example 1: Security Review
User request: "Review this login function for security issues"

Output: Review focusing on input validation, password handling, session management, and timing attack prevention.

### Example 2: Full PR Review
User request: "Can you review PR #42?"

Output: Complete review with context understanding, multi-category evaluation, structured feedback, and clear recommendation.

### Example 3: Quick Review
User request: "Just a quick look at these changes"

Output: Concise review highlighting only critical and warning-level issues.
